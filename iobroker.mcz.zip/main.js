// main adapter file (gekürzt für Downloadpaket)
