# ioBroker MCZ Maestro Adapter

MCZ Maestro (Air Matic 10 Core) ioBroker Adapter.
